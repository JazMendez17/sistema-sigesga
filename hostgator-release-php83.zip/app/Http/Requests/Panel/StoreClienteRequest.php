<?php

// FormRequest para validar los datos de clientes

namespace App\Http\Requests\Panel;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class StoreClienteRequest extends FormRequest
{
    // Autoriza la petición
    public function authorize(): bool
    {
        return true;
    }

    // Limpia los campos antes de la validación
    protected function prepareForValidation(): void
    {
        $data = $this->all();
        array_walk_recursive($data, function (&$value) {
            if (is_string($value)) {
                $value = trim($value) === '' ? null : trim($value);
            }
        });
        $this->merge($data);
        if ($this->isJson()) {
            $this->json()->replace($data);
        }
    }

    // Define las reglas de validación
    public function rules(): array
    {
        $id = $this->route('id');

        return [
            'nombre' => 'required|string|max:150',
            'apellido_paterno' => 'nullable|string|max:100',
            'apellido_materno' => 'nullable|string|max:100',
            'tipo_cliente' => 'required|in:persona_fisica,persona_moral',
            'sexo' => 'nullable|in:M,F',
            'curp' => ['nullable', 'string', 'size:18', Rule::unique('clientes', 'curp')
                ->where('empresa_id', $this->user()?->empresa_id)
                ->ignore($id)],
            'fecha_nacimiento' => 'nullable|date',
            'telefono' => 'nullable|string|max:20',
            'telefono_local' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:100',
            'folio_ine' => 'nullable|string|max:20',
            'nacionalidad' => 'required|string|max:50',
            'contacto_enlace' => 'nullable|string|max:150',
            'aseguradora_id' => 'nullable|exists:aseguradoras,id',
            'numero_poliza' => 'nullable|string|max:50',
            'tipo_cobertura_poliza' => 'nullable|string|max:100',
            'calle' => 'nullable|string|max:150',
            'numero_exterior' => 'nullable|string|max:50',
            'numero_interior' => 'nullable|string|max:50',
            'colonia' => 'nullable|string|max:100',
            'codigo_postal' => 'nullable|string|max:10',
            'municipio_alcaldia' => 'nullable|string|max:100',
            'ciudad' => 'nullable|string|max:100',
            'estado' => 'nullable|string|max:60',
            'pais' => 'nullable|string|max:60',
            'referencias' => 'nullable|string|max:500',
        ];
    }

    // Mensajes de error personalizados en español
    public function messages(): array
    {
        return [
            'nombre.required' => 'El nombre es obligatorio.',
            'nombre.max' => 'El nombre no debe exceder los 150 caracteres.',
            'tipo_cliente.required' => 'Selecciona el tipo de cliente.',
            'tipo_cliente.in' => 'El tipo de cliente debe ser persona_fisica o persona_moral.',
            'sexo.in' => 'El sexo debe ser M o F.',
            'curp.unique' => 'El CURP ya está registrado en esta empresa.',
            'curp.size' => 'El CURP debe tener exactamente 18 caracteres.',
            'fecha_nacimiento.date' => 'La fecha de nacimiento no tiene un formato válido.',
            'email.email' => 'El formato del correo electrónico no es válido.',
            'email.max' => 'El correo electrónico no debe exceder los 100 caracteres.',
            'folio_ine.max' => 'El folio INE no debe exceder los 20 caracteres.',
            'nacionalidad.required' => 'Selecciona la nacionalidad.',
            'nacionalidad.max' => 'La nacionalidad no debe exceder los 50 caracteres.',
            'aseguradora_id.exists' => 'La aseguradora seleccionada no existe.',
            'numero_poliza.max' => 'El número de póliza no debe exceder los 50 caracteres.',
            'codigo_postal.max' => 'El código postal no debe exceder los 10 caracteres.',
            'referencias.max' => 'Las referencias no deben exceder los 500 caracteres.',
        ];
    }

    // Lanza excepción con los errores de validación
    protected function failedValidation(Validator $validator): void
    {
        throw ValidationException::withMessages($validator->errors()->toArray());
    }
}
