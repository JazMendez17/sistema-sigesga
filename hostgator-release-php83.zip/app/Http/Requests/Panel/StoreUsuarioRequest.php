<?php

// FormRequest para validar los datos de usuarios

namespace App\Http\Requests\Panel;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class StoreUsuarioRequest extends FormRequest
{
    // Autoriza la petición
    public function authorize(): bool
    {
        return true;
    }

    // Limpia los campos antes de la validación
    protected function prepareForValidation(): void
    {
        $data = $this->all();
        array_walk_recursive($data, function (&$value) {
            if (is_string($value)) {
                $value = trim($value) === '' ? null : trim($value);
            }
        });
        $this->merge($data);
        if ($this->isJson()) {
            $this->json()->replace($data);
        }
    }

    // Define las reglas de validación
    public function rules(): array
    {
        $id = $this->route('id');
        $empresaId = $this->user()?->empresa_id;

        $rules = [
            'name' => 'required|string|max:150',
            'email' => ['required', 'email', 'max:150', Rule::unique('usuarios', 'email')
                ->where('empresa_id', $empresaId)
                ->ignore($id)],
            'rol' => 'required|in:admin,cotizador,operador,cliente',
            'empleado_id' => 'nullable|exists:empleados,id',
            'telefono' => 'nullable|string|max:20',
        ];

        if ($id) {
            $rules['password'] = ['nullable', 'string', 'min:8', 'regex:/[A-Z]/', 'regex:/[a-z]/', 'regex:/[0-9]/', 'regex:/[!@#$%^&*()_+\-=\[\]{}|;:,.<>?~]/'];
            $rules['cuenta_bloqueada'] = 'nullable|boolean';
        } else {
            $rules['password'] = ['required', 'string', 'min:8', 'regex:/[A-Z]/', 'regex:/[a-z]/', 'regex:/[0-9]/', 'regex:/[!@#$%^&*()_+\-=\[\]{}|;:,.<>?~]/'];
        }

        return $rules;
    }

    // Mensajes de error personalizados en español
    public function messages(): array
    {
        return [
            'name.required' => 'El nombre de usuario es obligatorio.',
            'name.max' => 'El nombre no debe exceder los 150 caracteres.',
            'email.required' => 'El correo electrónico es obligatorio.',
            'email.email' => 'El formato del correo electrónico no es válido.',
            'email.max' => 'El correo electrónico no debe exceder los 150 caracteres.',
            'email.unique' => 'El correo electrónico ya está registrado en esta empresa.',
            'password.required' => 'La contraseña es obligatoria.',
            'password.min' => 'La contraseña debe tener al menos 8 caracteres.',
            'password.regex' => 'La contraseña debe contener al menos una mayúscula, una minúscula, un número y un carácter especial (!@#$%^&*()_+-=[]{}|;:,.<>?~).',
            'password.string' => 'La contraseña debe ser una cadena de texto.',
            'rol.required' => 'El rol es obligatorio.',
            'rol.in' => 'El rol debe ser admin, cotizador, operador o cliente.',
            'empleado_id.exists' => 'El empleado seleccionado no existe.',
            'telefono.max' => 'El teléfono no debe exceder los 20 caracteres.',
            'cuenta_bloqueada.boolean' => 'El campo cuenta bloqueada debe ser verdadero o falso.',
        ];
    }

    // Lanza excepción con los errores de validación
    protected function failedValidation(Validator $validator): void
    {
        throw ValidationException::withMessages($validator->errors()->toArray());
    }
}
