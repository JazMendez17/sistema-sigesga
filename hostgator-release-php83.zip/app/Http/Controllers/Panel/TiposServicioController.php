<?php

// Controlador de tipos de servicio

namespace App\Http\Controllers\Panel;

use App\Http\Controllers\Controller;
use App\Support\Auditoria;
use App\Models\CatalogoServicio;
use App\Http\Requests\Panel\StoreTipoServicioRequest;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class TiposServicioController extends Controller
{
    // Lista de tipos de servicio
    public function index()
    {
        $user = Auth::user();
        $empresaId = $user->empresa_id;

        $tipos = CatalogoServicio::where('empresa_id', $empresaId)
            ->latest()
            ->get()
            ->map(fn ($t) => [
                'id' => $t->id,
                'nombre' => $t->nombre ?? '—',
                'requiere_maniobra' => $t->requiere_maniobra ?? false,
                'activo' => $t->activo ?? true,
            ]);

        return Inertia::render('Panel/TiposServicio/Index', [
            'tiposServicio' => $tipos,
        ]);
    }

    // Formulario para crear tipo de servicio
    public function create()
    {
        return Inertia::render('Panel/TiposServicio/Create');
    }

    // Guardar tipo de servicio en base de datos
    public function store(StoreTipoServicioRequest $request)
    {
        $user = Auth::user();

        $data = $request->validated();
        $data['empresa_id'] = $user->empresa_id;
        $data['requiere_maniobra'] = $request->boolean('requiere_maniobra');
        $data['activo'] = $request->boolean('activo');

        CatalogoServicio::create($data);

        return back()->with('success', 'Tipo de servicio creado correctamente');
    }

    // Formulario para editar tipo de servicio
    public function edit($id)
    {
        return Inertia::render('Panel/TiposServicio/Create', [
            'tipoServicio' => CatalogoServicio::findOrFail($id),
        ]);
    }

    // Actualizar datos de tipo de servicio
    public function update(StoreTipoServicioRequest $request, $id)
    {
        $tipo = CatalogoServicio::findOrFail($id);

        // Actualización parcial: solo se tocan los campos enviados para que
        // activar/desactivar no borre el otro interruptor.
        $data = $request->validated();

        if ($request->has('requiere_maniobra')) {
            $data['requiere_maniobra'] = $request->boolean('requiere_maniobra');
        }
        if ($request->has('activo')) {
            $data['activo'] = $request->boolean('activo');
        }

        $tipo->update($data);

        return back()->with('success', 'Tipo de servicio actualizado correctamente');
    }

    // Eliminar tipo de servicio
    public function destroy($id)
    {
        $tipo = CatalogoServicio::findOrFail($id);

        Auditoria::registrar($tipo);

        $tipo->eliminar();

        return back()->with('success', 'Tipo de servicio eliminado correctamente');
    }
}
