<?php

// Controlador de cotizaciones

namespace App\Http\Controllers\Panel;

use App\Http\Controllers\Controller;
use App\Support\Auditoria;
use App\Models\Cotizacione;
use App\Models\Cliente;
use App\Models\CatalogoServicio;
use App\Models\Convenio;
use App\Models\ConvenioTarifa;
use App\Models\ConvenioConceptoAdicional;
use App\Models\TarifasEmpresa;
use App\Models\Servicio;
use App\Models\Operadore;
use App\Models\Unidade;
use App\Models\Oficina;
use App\Http\Requests\Panel\StoreCotizacionRequest;
use App\Http\Requests\Panel\BuscarRutasCotizacionRequest;
use App\Services\GoogleMapsService;
use App\Mail\CotizacionMail;
use App\Models\Notificacione;
use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Inertia\Inertia;

class CotizacionesController extends Controller
{
    // Lista de cotizaciones
    public function index()
    {
        $user = Auth::user();
        $empresaId = $user->empresa_id;

        $cotizaciones = Cotizacione::with(['cliente', 'tipoServicio', 'usuarioCreador'])
            ->where('empresa_id', $empresaId)
            ->latest()
            ->get()
            ->map(fn ($c) => [
                'id' => $c->id,
                'folio' => $c->folio ?? 'COT-' . str_pad($c->id, 5, '0', STR_PAD_LEFT),
                'cliente' => $c->cliente?->nombre ?? '—',
                'tipo' => $c->tipoServicio?->nombre ?? '—',
                'origen' => $c->origen_direccion ?? '—',
                'destino' => $c->destino_direccion ?? '—',
                'total' => (float) ($c->costo_total ?? 0),
                'estatus' => $c->estatus ?? 'pendiente',
                'fecha' => $c->created_at?->format('d/m/Y'),
            ]);

        return Inertia::render('Panel/Cotizaciones/Index', [
            'cotizaciones' => $cotizaciones,
        ]);
    }

    // Formulario para crear cotización
    public function create()
    {
        $user = Auth::user();
        $empresaId = $user->empresa_id;

        return Inertia::render('Panel/Cotizaciones/Create', [
            'clientes' => Cliente::where('empresa_id', $empresaId)->get(['id', 'nombre', 'apellido_paterno', 'apellido_materno']),
            'tiposServicio' => CatalogoServicio::where('empresa_id', $empresaId)->get(['id', 'nombre']),
            // Llave del navegador para Places Autocomplete + Maps JS (restringida por referrer).
            'googleMapsKey' => config('services.google.frontend_key'),
        ]);
    }

    // Calcular rutas (distancias, tiempos y peajes) para una cotización.
    // Actúa como proxy seguro hacia Google Routes API v2: el frontend nunca ve
    // la llave de servidor ni decide el field mask.
    public function rutas(BuscarRutasCotizacionRequest $request)
    {
        try {
            $resultado = app(GoogleMapsService::class)->rutas($request->validated());

            return response()->json(['ok' => true] + $resultado);
        } catch (\Throwable $e) {
            // Errores de Google o de conexión se devuelven como mensaje amigable.
            return response()->json([
                'ok' => false,
                'error' => $e->getMessage(),
            ], 422);
        }
    }

    // Guardar cotización en base de datos
    public function store(StoreCotizacionRequest $request)
    {
        $user = Auth::user();

        $data = $request->validated();
        $data['empresa_id'] = $user->empresa_id;
        $data['usuario_creador_id'] = $user->id;
        $data['estatus'] = 'pendiente';

        if (empty($data['folio'])) {
            // El índice único es global e incluye registros ocultos/eliminados,
            // por eso se debe consultar también con `conEliminados()`.
            $ultimoFolio = Cotizacione::query()
                ->conEliminados()
                ->where('folio', 'like', 'COT-%')
                ->lockForUpdate()
                ->orderByDesc('folio')
                ->value('folio');
            $siguienteNumero = $ultimoFolio ? ((int) substr($ultimoFolio, 4)) + 1 : 1;
            $data['folio'] = 'COT-' . str_pad($siguienteNumero, 5, '0', STR_PAD_LEFT);
        }

        $cotizacion = DB::transaction(function () use ($data) {
            $cotizacion = Cotizacione::create($data);
            $cliente = Cliente::with('usuario')->find($cotizacion->cliente_id);
            $usuarioCliente = $cliente?->usuario;

            if ($usuarioCliente) {
                $this->crearNotificacion($cotizacion->empresa_id, $usuarioCliente->id,
                    "Nueva cotización {$cotizacion->folio} disponible para revisión y aprobación en tu portal.");
            }

            $this->notificarRolesCotizacion($cotizacion,
                "Nueva cotización {$cotizacion->folio} creada para {$cliente?->nombre}. Pendiente de aprobación del cliente.");

            return $cotizacion;
        });

        $cliente = Cliente::with('usuario')->find($cotizacion->cliente_id);
        $usuarioCliente = $cliente?->usuario;

        $correo = $cliente?->email ?: $usuarioCliente?->email;
        if ($correo) {
            try {
                Mail::to($correo)->send(new CotizacionMail($cotizacion->load('cliente', 'tipoServicio')));
            } catch (\Throwable $e) {
                Log::error('Error al enviar cotización por email', [
                    'cotizacion_id' => $cotizacion->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return redirect()->route('panel.cotizaciones.index')
            ->with('success', 'Cotización creada correctamente');
    }

    // Ver detalle de cotización
    public function show($id)
    {
        $user = Auth::user();

        $query = Cotizacione::with(['cliente', 'tipoServicio', 'usuarioCreador', 'servicio'])->where('empresa_id', $user->empresa_id);

        if ($user->rol === 'cliente') {
            $cliente = Cliente::where('usuario_id', $user->id)->first();
            if (!$cliente) {
                abort(404);
            }
            $query->where('cliente_id', $cliente->id);
        }

        $cotizacion = $query->findOrFail($id);

        return Inertia::render('Panel/Cotizaciones/Show', [
            'cotizacion' => [
                'id' => $cotizacion->id,
                'folio' => $cotizacion->folio ?? 'COT-' . str_pad($cotizacion->id, 5, '0', STR_PAD_LEFT),
                'cliente' => $cotizacion->cliente?->nombre ?? '—',
                'fecha' => $cotizacion->created_at?->format('d/m/Y'),
                'tipo' => $cotizacion->tipoServicio?->nombre ?? '—',
                'estatus' => $cotizacion->estatus ?? 'pendiente',
                'origen' => $cotizacion->origen_direccion ?? '—',
                'destino' => $cotizacion->destino_direccion ?? '—',
                'distancia' => (float) ($cotizacion->distancia_km ?? 0),
                    'banderazo' => (float) ($cotizacion->costo_banderazo ?? 0),
                    'km_incluidos' => (float) ($cotizacion->km_incluidos ?? 0),
                    'km_excedente' => (float) ($cotizacion->km_excedente ?? 0),
                    'costo_km' => (float) ($cotizacion->costo_km ?? 0),
                    'subtotal' => (float) ($cotizacion->subtotal ?? 0),
                    'descuento_pct' => (float) ($cotizacion->descuento_pct ?? 0),
                    'monto_descuento' => (float) ($cotizacion->monto_descuento ?? 0),
                    'iva' => (float) ($cotizacion->monto_iva ?? 0),
                    'casetas' => (float) ($cotizacion->costo_aprox_casetas ?? 0),
                    'incluye_peajes' => (bool) ($cotizacion->incluye_peajes ?? false),
                'total_estimado' => (float) ($cotizacion->costo_total ?? 0),
                'usuario_creador' => $cotizacion->usuarioCreador?->name ?? '—',
                'servicio_id' => $cotizacion->servicio?->id,
                'cliente_aprobada_at' => $cotizacion->cliente_aprobada_at,
                'aprobada_internamente_at' => $cotizacion->aprobada_internamente_at,
                'puede_aprobar_cliente' => $user->rol === 'cliente'
                    && !$cotizacion->cliente_aprobada_at
                    && $cotizacion->estatus === 'pendiente',
                'es_cliente' => $user->rol === 'cliente',
            ],
            'operadores' => $user->rol === 'cliente' ? [] : Operadore::with('empleado')->where('empresa_id', $user->empresa_id)->where('disponible', true)->get()->map(fn($o) => [
                'id' => $o->id, 'nombre' => $o->empleado?->nombre ? trim($o->empleado->nombre.' '.($o->empleado->apellido_paterno??'')) : ('Operador #'.$o->id),
            ]),
            'unidades' => $user->rol === 'cliente' ? [] : Unidade::where('empresa_id', $user->empresa_id)->where('activo', true)->get(['id', 'placas', 'numero_economico']),
        ]);
    }

    // Aprobar cotización y crear servicio
    public function aprobar(Request $request, $id)
    {
        $empresaId = auth()->user()->empresa_id;
        $cotizacion = Cotizacione::where('empresa_id', $empresaId)->findOrFail($id);

        if ($cotizacion->estatus === 'aprobado' || $cotizacion->servicio) {
            return back()->with('error', 'Esta cotización ya fue aprobada y tiene un servicio asociado.');
        }

        if (!$cotizacion->cliente_aprobada_at) {
            return back()->with('error', 'La cotización debe ser aprobada por el cliente o aseguradora antes de crear el servicio.');
        }

        $data = $request->validate([
            'operador_id' => ['required', \Illuminate\Validation\Rule::exists('operadores', 'id')->where('empresa_id', $empresaId)],
            'unidad_id' => ['required', \Illuminate\Validation\Rule::exists('unidades', 'id')->where('empresa_id', $empresaId)],
        ]);

        DB::transaction(function () use ($cotizacion, $data, $empresaId) {
            $cotizacion = Cotizacione::where('empresa_id', $empresaId)->lockForUpdate()->findOrFail($cotizacion->id);
            if ($cotizacion->servicio) {
                throw \Illuminate\Validation\ValidationException::withMessages(['cotizacion' => 'La cotización ya tiene un servicio asociado.']);
            }
            $operador = Operadore::where('empresa_id', $empresaId)->lockForUpdate()->findOrFail($data['operador_id']);
            $unidad = \App\Models\Unidade::where('empresa_id', $empresaId)->lockForUpdate()->findOrFail($data['unidad_id']);
            $estadosActivos = ['asignado', 'inicio_servicio', 'en_sitio_origen', 'salida_destino', 'en_destino'];
            $operadorOcupado = Servicio::where('empresa_id', $empresaId)->where('operador_id', $operador->id)->whereIn('estado', $estadosActivos)->exists();
            $unidadOcupada = Servicio::where('empresa_id', $empresaId)->where('unidad_id', $unidad->id)->whereIn('estado', $estadosActivos)->exists();
            if (!$operador->disponible || $operadorOcupado || !$unidad->activo || $unidadOcupada) {
                throw \Illuminate\Validation\ValidationException::withMessages(['operador_id' => 'El operador o la unidad no están disponibles. Actualiza la página e intenta de nuevo.']);
            }
            $cotizacion->update([
                'estatus' => 'aprobado',
                'aprobada_internamente_at' => now(),
            ]);

            Servicio::create([
                'empresa_id' => $cotizacion->empresa_id,
                'cotizacion_id' => $cotizacion->id,
                'operador_id' => $operador->id,
                'unidad_id' => $unidad->id,
                'estado' => 'asignado',
                'costo_final_real' => $cotizacion->costo_total,
            ]);

            $operador->update(['disponible' => false]);
        });

        return back()->with('success', 'Cotización aprobada y servicio creado correctamente.');
    }

    // Rechazar cotización
    public function rechazar(Request $request, $id)
    {
        $cotizacion = Cotizacione::where('empresa_id', auth()->user()->empresa_id)->findOrFail($id);
        $cotizacion->update(['estatus' => 'rechazado']);

        return back()->with('success', 'Cotización rechazada.');
    }

    public function aprobarCliente($id)
    {
        $usuario = auth()->user();
        $cliente = Cliente::where('usuario_id', $usuario->id)->firstOrFail();
        $cotizacion = Cotizacione::where('cliente_id', $cliente->id)->findOrFail($id);

        if ($cotizacion->estatus !== 'pendiente' || $cotizacion->cliente_aprobada_at) {
            return back()->with('error', 'Esta cotización ya no está disponible para aprobación.');
        }

        $cotizacion->update(['cliente_aprobada_at' => now()]);

        $ids = Usuario::where('empresa_id', $cotizacion->empresa_id)
            ->whereIn('rol', ['admin', 'cotizador'])
            ->pluck('id')
            ->push($cotizacion->usuario_creador_id)
            ->unique();
        foreach ($ids as $usuarioId) {
            $this->crearNotificacion($cotizacion->empresa_id, $usuarioId,
                "El cliente aprobó la cotización {$cotizacion->folio}. Requiere aprobación interna.");
        }

        return back()->with('success', 'Cotización aprobada. El equipo interno continuará con la autorización.');
    }

    protected function crearNotificacion(int $empresaId, int $usuarioId, string $mensaje): void
    {
        Notificacione::create([
            'empresa_id' => $empresaId,
            'usuario_id' => $usuarioId,
            'mensaje' => $mensaje,
            'canal' => 'sistema_push',
            'estado' => 'pendiente',
        ]);
    }

    protected function notificarRolesCotizacion(Cotizacione $cotizacion, string $mensaje): void
    {
        Usuario::where('empresa_id', $cotizacion->empresa_id)
            ->whereIn('rol', ['admin', 'cotizador'])
            ->where('id', '!=', auth()->id())
            ->pluck('id')
            ->each(fn ($usuarioId) => $this->crearNotificacion($cotizacion->empresa_id, $usuarioId, $mensaje));
    }

    // Formulario para editar cotización
    public function edit($id)
    {
        $user = Auth::user();
        $empresaId = $user->empresa_id;
        $cotizacion = Cotizacione::where('empresa_id', auth()->user()->empresa_id)->findOrFail($id);

        return Inertia::render('Panel/Cotizaciones/Create', [
            'cotizacion' => $cotizacion,
            'clientes' => Cliente::where('empresa_id', $empresaId)->get(['id', 'nombre']),
            'tiposServicio' => CatalogoServicio::where('empresa_id', $empresaId)->get(['id', 'nombre']),
            'googleMapsKey' => config('services.google.frontend_key'),
        ]);
    }

    // Actualizar datos de cotización
    public function update(StoreCotizacionRequest $request, $id)
    {
        $cotizacion = Cotizacione::where('empresa_id', auth()->user()->empresa_id)->findOrFail($id);

        $data = $request->validated();

        $cotizacion->update($data);

        return redirect()->route('panel.cotizaciones.index')
            ->with('success', 'Cotización actualizada correctamente');
    }

    // Eliminar cotización
    public function destroy($id)
    {
        $cotizacion = Cotizacione::where('empresa_id', auth()->user()->empresa_id)->findOrFail($id);

        Auditoria::registrar($cotizacion);

        $cotizacion->eliminar();

        return redirect()->route('panel.cotizaciones.index')
            ->with('success', 'Cotización eliminada correctamente');
    }

    // Vista de cotizaciones para el cliente
    public function misCotizaciones()
    {
        $cliente = \App\Models\Cliente::where('usuario_id', auth()->id())->first();
        $cotizaciones = Cotizacione::where('cliente_id', $cliente?->id)
            ->with('tipoServicio')
            ->latest()
            ->get()
            ->map(fn ($c) => [
                'id' => $c->id,
                'folio' => $c->folio ?? 'COT-' . str_pad($c->id, 5, '0', STR_PAD_LEFT),
                'tipo' => $c->tipoServicio?->nombre ?? '—',
                'origen' => $c->origen_direccion ?? '—',
                'destino' => $c->destino_direccion ?? '—',
                'estatus' => $c->estatus,
                'fecha' => $c->created_at?->format('d/m/Y'),
                'total' => '$' . number_format($c->costo_total ?? 0, 2),
            ]);

        return Inertia::render('Panel/ClienteCotizaciones', ['cotizaciones' => $cotizaciones]);
    }

    // API: Obtener tarifa según cliente y tipo de servicio para auto-llenado
    public function obtenerTarifa(Request $request)
    {
        $empresaId = auth()->user()->empresa_id;
        $cliente = Cliente::with('aseguradora')->where('empresa_id', $empresaId)->find($request->cliente_id);
        $tipoServicioId = $request->tipo_servicio_id;

        if (!$cliente || !$tipoServicioId || !CatalogoServicio::where('empresa_id', $empresaId)->whereKey($tipoServicioId)->exists()) {
            return response()->json(null);
        }

        // Si el cliente tiene aseguradora, buscar en convenio_tarifas
        if ($cliente->aseguradora_id) {
            $convenio = Convenio::where('aseguradora_id', $cliente->aseguradora_id)
                ->where('empresa_id', auth()->user()->empresa_id)
                ->first();

            if ($convenio) {
                $tarifa = ConvenioTarifa::where('convenio_id', $convenio->id)
                    ->where('servicio_id', $tipoServicioId)
                    ->first();

                $conceptos = ConvenioConceptoAdicional::where('convenio_id', $convenio->id)->first();

                return response()->json([
                    'origen' => 'convenio',
                    'convenio_id' => $convenio->id,
                    'convenio_nombre' => $convenio->nombre_convenio_poliza,
                    'banderazo' => (float) ($tarifa->banderazo ?? 0),
                    'km_incluidos' => (int) ($tarifa->km_incluidos ?? 0),
                    'costo_km_extra' => (float) ($tarifa->costo_km_extra ?? 0),
                    'cubre_casetas' => $conceptos?->cubre_casetas ?? false,
                    'incluye_casetas' => (bool) ($conceptos?->cubre_casetas ?? false),
                    'tarifa_nocturna_recargo_pct' => (float) ($tarifa->tarifa_nocturna_recargo_pct ?? 0),
                    'tarifa_domingo_festivo_recargo_pct' => (float) ($tarifa->tarifa_domingo_festivo_recargo_pct ?? 0),
                    'minutos_espera_incluidos' => (int) ($tarifa->minutos_espera_incluidos ?? 0),
                    'costo_espera_adicional_hora' => (float) ($tarifa->costo_espera_adicional_hora ?? 0),
                    'descuento_pct' => (float) ($tarifa->descuento_pct ?? 0),
                ]);
            }
        }

        // Si no tiene aseguradora o no se encontró convenio, buscar tarifa propia
        $tarifaPropia = TarifasEmpresa::where('tipo_servicio_id', $tipoServicioId)
            ->where('empresa_id', $empresaId)
            ->where('activo', true)
            ->first();

        if ($tarifaPropia) {
            return response()->json([
                'origen' => 'propia',
                'tarifa_empresa_id' => $tarifaPropia->id,
                'banderazo' => (float) $tarifaPropia->costo_banderazo,
                'km_incluidos' => (float) $tarifaPropia->km_incluidos,
                'costo_km_extra' => (float) ($tarifaPropia->costo_km ?? 0),
                'cubre_casetas' => (bool) $tarifaPropia->cubre_casetas_peaje,
                'incluye_casetas' => (bool) $tarifaPropia->cubre_casetas_peaje,
                'descuento_pct' => 0,
            ]);
        }

        return response()->json(null);
    }
}
