<script setup>
import { computed } from 'vue';
import { Link } from '@inertiajs/vue3';

const props = defineProps({
    href: {
        type: String,
        required: true,
    },
    active: {
        type: Boolean,
    },
});

const classes = computed(() =>
    props.active
        ? 'block w-full ps-3 pe-4 py-2 border-l-4 border-[var(--color-secondary)] text-start text-base font-medium text-[var(--color-secondary)] bg-[var(--color-secondary-light)] focus:outline-none focus:text-[var(--color-secondary)] focus:bg-[var(--color-secondary-light)] focus:border-[var(--color-secondary)] transition duration-150 ease-in-out'
        : 'block w-full ps-3 pe-4 py-2 border-l-4 border-transparent text-start text-base font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300 focus:outline-none focus:text-gray-800 focus:bg-gray-50 focus:border-gray-300 transition duration-150 ease-in-out',
);
</script>

<!-- Enlace de navegación responsive con indicador lateral activo -->
<template>
    <!-- Enlace responsive con borde lateral para estado activo -->
    <Link :href="href" :class="classes">
        <slot />
    </Link>
</template>
