<script setup>
import { ref, computed, onMounted, reactive } from 'vue'
import { Head, usePage } from '@inertiajs/vue3'
import { useTheme } from '@/Composables/useTheme'

useTheme()

const props = defineProps({
    canLogin: Boolean,
    canRegister: Boolean,
    servicios: { type: Array, default: () => [] },
    redesSociales: { type: Array, default: () => [] },
    nosotros: { type: Object, default: () => ({}) },
    valores: { type: Array, default: () => [] },
})

const empresa = computed(() => usePage().props.empresa || {})
const redesSociales = computed(() => usePage().props.redesSociales || [])
const serviciosConfigurados = computed(() => props.servicios || [])
const mobileMenuOpen = ref(false)
const activeSection = ref('inicio')

const nosotrosData = computed(() => props.nosotros || {})
const valoresData = computed(() => props.valores || [])

const cssVars = computed(() => ({
    '--color-primary': empresa.value.color_primario || '#4F46E5',
    '--color-secondary': empresa.value.color_secundario || '#7C3AED',
    '--color-accent': empresa.value.color_secundario || '#d97706',
    '--font-family': empresa.value.tipografia ? `"${empresa.value.tipografia}", sans-serif` : 'Roboto, sans-serif',
}))

onMounted(() => {
    const font = empresa.value.tipografia
    if (font) {
        const link = document.createElement('link')
        link.href = `https://fonts.googleapis.com/css2?family=${font.replace(/ /g, '+')}:wght@300;400;500;600;700;800&display=swap`
        link.rel = 'stylesheet'
        document.head.appendChild(link)
    }
})

const switchSection = (id) => {
    mobileMenuOpen.value = false
    activeSection.value = id
}

const navLinks = [
    { label: 'Inicio', id: 'inicio' },
    { label: 'Nosotros', id: 'nosotros' },
    { label: 'Servicio', id: 'servicio' },
    { label: 'Contacto', id: 'contacto' },
]

const valoresIconos = ['shield', 'heart', 'check', 'star', 'bulb', 'users']

const form = reactive({
    nombre: '',
    email: '',
    mensaje: '',
})
const contactoEnviado = ref(false)

const submitContacto = async () => {
    if (!form.nombre || !form.email || !form.mensaje) return
    try {
        const res = await fetch('/contacto', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]')?.content },
            body: JSON.stringify({ ...form }),
        })
        if (res.ok) {
            contactoEnviado.value = true
            form.nombre = ''
            form.email = ''
            form.mensaje = ''
            setTimeout(() => { contactoEnviado.value = false }, 6000)
        }
    } catch (e) {
        console.error('Error al enviar contacto:', e)
    }
}

const flash = computed(() => usePage().props.flash || {})

const icons = {
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg>',
    heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>',
    star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
    bulb: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>',
    users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>',
    truck: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 17h8M8 17a2 2 0 11-4 0 2 2 0 014 0zm8 0a2 2 0 104 0 2 2 0 00-4 0zm-9-3V5a1 1 0 011-1h9a1 1 0 011 1v9M3 14h1m16 0h1M5 10h14"/></svg>',
    wrench: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11.42 15.17l-7.5 7.5a2 2 0 01-2.83-2.83l7.5-7.5m2.83 2.83a6 6 0 11-2.83-2.83zm0 0l5.66-5.66M14.24 9.24l5.66-5.66M14.24 9.24A6 6 0 0112 4.24M17.66 6.34L20 4"/></svg>',
    battery: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="6" width="18" height="12" rx="2" ry="2"/><line x1="23" y1="10" x2="23" y2="14"/><line x1="7" y1="10" x2="7" y2="14"/><line x1="11" y1="10" x2="11" y2="14"/><line x1="15" y1="10" x2="15" y2="14"/></svg>',
    key: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 7a4 4 0 11-8 0 4 4 0 018 0zm0 0l4 4m-4-4l4-4m-4 4l-4 4"/><path d="M7 11l-3 3m0 0l3 3m-3-3h8"/></svg>',
    clipboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 012-2h2a2 2 0 012 2M9 5h6"/><path d="M9 12l2 2 4-4"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>',
    document: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>',
    chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>',
    mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>',
    pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    arrowRight: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',
}

const getIcon = (name) => icons[name] || ''
</script>

<template>
    <!-- Landing page principal con secciones: inicio, nosotros, servicio, contacto -->
    <Head :title="empresa.nombre || 'SIGESGA'" />

    <div :style="cssVars" class="bg-[var(--color-bg)] h-screen overflow-hidden flex flex-col" style="color: var(--color-text)">
        <div v-if="flash.success" class="fixed top-4 right-4 z-[100] max-w-sm p-4 rounded-2xl bg-emerald-50 text-emerald-800 shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff] flex items-center gap-3 animate-[slideIn_0.3s_ease-out]">
            <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <p class="text-sm font-medium">{{ flash.success }}</p>
            <button @click="flash.success = null" class="ml-auto text-emerald-600 hover:text-emerald-800">&times;</button>
        </div>
        <div v-if="flash.error" class="fixed top-4 right-4 z-[100] max-w-sm p-4 rounded-2xl bg-red-50 text-red-800 shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff] flex items-center gap-3 animate-[slideIn_0.3s_ease-out]">
            <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
            <p class="text-sm font-medium">{{ flash.error }}</p>
            <button @click="flash.error = null" class="ml-auto text-red-600 hover:text-red-800">&times;</button>
        </div>
        <nav class="shrink-0 z-50 bg-[var(--color-bg)] shadow-[8px_8px_16px_var(--neumorphic-dark),-8px_-8px_16px_var(--neumorphic-light)] transition-all duration-300 py-3 px-4 md:px-8">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <button type="button" @click="switchSection('inicio')" class="flex items-center gap-3 group">
                    <div v-if="empresa.logo" class="w-10 h-10 rounded-2xl overflow-hidden shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff]">
                        <img :src="'/storage/' + empresa.logo" :alt="empresa.nombre" class="w-full h-full object-contain" />
                    </div>
                    <div v-else class="w-10 h-10 rounded-2xl bg-[var(--color-bg)] flex items-center justify-center text-lg font-bold shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff]"
                         :style="{ color: 'var(--color-primary)' }">
                        {{ (empresa.siglas || empresa.nombre || 'SG').charAt(0) }}
                    </div>
                    <span class="font-semibold text-lg hidden sm:block" :style="{ color: 'var(--color-primary)' }">
                        {{ empresa.siglas || empresa.nombre || 'SIGESGA' }}
                    </span>
                </button>

                <div class="hidden md:flex items-center gap-1">
                          <button v-for="link in navLinks" :key="link.id" type="button"
                              @click="switchSection(link.id)"
                       class="px-4 py-2 rounded-2xl text-sm font-medium transition-all duration-200 hover:shadow-[inset_4px_4px_8px_#d0d5da,inset_-4px_-4px_8px_#ffffff] text-[var(--color-text)]">
                        {{ link.label }}
                    </button>
                </div>

<div class="hidden md:flex items-center gap-3">
    <a href="/login"
       class="px-5 py-2 rounded-2xl text-sm font-medium transition-all duration-200 shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff] hover:shadow-[6px_6px_12px_#c9ced3,-6px_-6px_12px_#ffffff]"
       :style="{ color: 'var(--color-primary)' }">
        Iniciar Sesión
    </a>
    <a href="/register"
       class="px-5 py-2 rounded-2xl text-sm font-semibold text-white transition-all duration-200 shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff] hover:shadow-[6px_6px_12px_#c9ced3,-6px_-6px_12px_#ffffff]"
       :style="{ backgroundColor: 'var(--color-primary)' }">
        Registrarse
    </a>
</div>

                <button @click="mobileMenuOpen = !mobileMenuOpen"
                        class="md:hidden p-2 rounded-2xl shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff] text-[var(--color-text)] transition-all duration-200">
                    <span class="w-6 h-6 block" v-html="getIcon(mobileMenuOpen ? 'x' : 'menu')"></span>
                </button>
            </div>

            <div v-if="mobileMenuOpen"
                 class="md:hidden mt-3 rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff] p-4 space-y-2">
                     <button v-for="link in navLinks" :key="link.id" type="button"
                         @click="switchSection(link.id)"
                   class="block px-4 py-3 rounded-2xl text-sm font-medium text-[var(--color-text)] hover:shadow-[inset_4px_4px_8px_#d0d5da,inset_-4px_-4px_8px_#ffffff] transition-all duration-200">
                    {{ link.label }}
                </button>
                <hr class="border-gray-300 my-2" />
                <a href="/login"
                   class="block w-full px-4 py-3 rounded-2xl text-sm font-medium text-center transition-all duration-200 shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff]"
                   :style="{ color: 'var(--color-primary)' }">
                    Iniciar Sesión
                </a>
                <a href="/register"
                   class="block w-full px-4 py-3 rounded-2xl text-sm font-semibold text-white text-center transition-all duration-200 shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff]"
                   :style="{ backgroundColor: 'var(--color-primary)' }">
                    Registrarse
                </a>
            </div>
        </nav>

        <main class="min-h-0 flex-1 overflow-hidden">
        <section v-if="activeSection === 'inicio'" id="inicio" class="relative h-full flex items-center overflow-hidden">
            <div v-if="empresa.imagen_fondo" class="absolute inset-0">
                <img :src="'/storage/' + empresa.imagen_fondo" alt="" class="w-full h-full object-cover" />
            </div>
            <div v-else class="absolute inset-0 bg-gradient-to-br from-[#1e3a5f] via-[#2d5a87] to-[#1e3a5f]"></div>
            <div class="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-black/30"></div>
            <div class="absolute inset-0 bg-gradient-to-t from-[#E8EDF2] via-transparent to-transparent opacity-30"></div>

            <div class="relative z-10 max-w-7xl mx-auto px-4 md:px-8 w-full">
                <div class="max-w-3xl">
                    <h1 class="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6">
                        Sistema Integral de Gestión de Servicios de Grúas y Asistencia Vial
                    </h1>
                    <p v-if="empresa.slogan" class="text-xl md:text-2xl text-white/80 mb-10 font-light">
                        {{ empresa.slogan }}
                    </p>
                    <a href="/register"
                       class="inline-flex items-center gap-2 px-8 py-4 rounded-3xl text-lg font-semibold text-white transition-all duration-300 shadow-[8px_8px_16px_#00000033,-8px_-8px_16px_#ffffff1a] hover:shadow-[10px_10px_20px_#0000004d,-10px_-10px_20px_#ffffff33] hover:scale-[1.02]"
                       :style="{ backgroundColor: 'var(--color-primary)' }">
                        Comenzar
                        <span class="w-5 h-5" v-html="getIcon('arrowRight')"></span>
                    </a>
                </div>
            </div>

            <div class="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
                <button type="button" @click="switchSection('nosotros')" class="text-white/60 hover:text-white transition-colors">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </svg>
                </button>
            </div>
        </section>

        <section v-else-if="activeSection === 'nosotros'" id="nosotros" class="h-full overflow-y-auto py-12 md:py-20 px-4 md:px-8">
            <div class="max-w-7xl mx-auto">
                <div class="text-center mb-16">
                    <h2 class="text-3xl md:text-4xl font-bold mb-4" :style="{ color: 'var(--color-primary)' }">Nosotros</h2>
                    <div class="w-20 h-1 rounded-full mx-auto" :style="{ backgroundColor: 'var(--color-primary)' }"></div>
                </div>

                <div class="grid md:grid-cols-3 gap-8 mb-20">
                    <div class="p-8 rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff] transition-all duration-300 hover:shadow-[12px_12px_24px_#c9ced3,-12px_-12px_24px_#ffffff]">
                        <h3 class="text-xl font-bold mb-4" :style="{ color: 'var(--color-primary)' }">Quiénes Somos</h3>
                        <p class="text-gray-600 leading-relaxed">
                            {{ nosotrosData.quienes_somos || 'Somos una empresa dedicada a la prestación de servicios de grúas y asistencia vial, comprometidos con la calidad y la satisfacción de nuestros clientes.' }}
                        </p>
                    </div>
                    <div class="p-8 rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff] transition-all duration-300 hover:shadow-[12px_12px_24px_#c9ced3,-12px_-12px_24px_#ffffff]">
                        <h3 class="text-xl font-bold mb-4" :style="{ color: 'var(--color-primary)' }">Misión</h3>
                        <p class="text-gray-600 leading-relaxed">
                            {{ nosotrosData.mision || 'Brindar servicios de grúas y asistencia vial con rapidez, seguridad y calidad, superando las expectativas de nuestros clientes.' }}
                        </p>
                    </div>
                    <div class="p-8 rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff] transition-all duration-300 hover:shadow-[12px_12px_24px_#c9ced3,-12px_-12px_24px_#ffffff]">
                        <h3 class="text-xl font-bold mb-4" :style="{ color: 'var(--color-primary)' }">Visión</h3>
                        <p class="text-gray-600 leading-relaxed">
                            {{ nosotrosData.vision || 'Ser la empresa líder en servicios de grúas y asistencia vial a nivel nacional, reconocida por nuestra excelencia operativa.' }}
                        </p>
                    </div>
                </div>

                <div class="mb-20">
                    <h3 class="text-2xl font-bold text-center mb-4" :style="{ color: 'var(--color-primary)' }">Nuestros Valores</h3>
                    <p class="text-gray-500 text-center mb-10 max-w-2xl mx-auto">Los principios que guían cada uno de nuestros servicios y decisiones.</p>
                    <div v-if="valoresData.length" class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div v-for="(val, i) in valoresData" :key="val.valor || i"
                             class="p-6 rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff] transition-all duration-300 hover:shadow-[12px_12px_24px_#c9ced3,-12px_-12px_24px_#ffffff] group">
                            <div class="w-12 h-12 rounded-2xl bg-[var(--color-bg)] shadow-[inset_4px_4px_8px_#d0d5da,inset_-4px_-4px_8px_#ffffff] flex items-center justify-center mb-4 group-hover:shadow-[inset_6px_6px_12px_#c9ced3,inset_-6px_-6px_12px_#ffffff] transition-all duration-300"
                                 :style="{ color: 'var(--color-primary)' }">
                                <span class="w-6 h-6" v-html="getIcon(valoresIconos[i % valoresIconos.length])"></span>
                            </div>
                            <h4 class="text-lg font-bold mb-2 text-gray-800">{{ val.valor }}</h4>
                            <p class="text-sm text-gray-500 leading-relaxed">{{ val.descripcion }}</p>
                        </div>
                    </div>
                    <p v-else class="text-center text-gray-500">No hay valores configurados.</p>
                </div>

                <div>
                    <h3 class="text-2xl font-bold text-center mb-4" :style="{ color: 'var(--color-primary)' }">Accesos Rápidos</h3>
                    <p class="text-gray-500 text-center mb-10 max-w-2xl mx-auto">Conéctate con nosotros en nuestras redes sociales.</p>
                    <div v-if="redesSociales.length" class="flex flex-wrap justify-center gap-6">
                        <div v-for="red in redesSociales" :key="red.id || red.titulo"
                             class="w-full sm:w-[calc(50%-12px)] lg:w-[calc(25%-18px)] max-w-xs p-6 rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff] transition-all duration-300 hover:shadow-[12px_12px_24px_#c9ced3,-12px_-12px_24px_#ffffff] group text-center">
                            <div class="w-20 h-20 rounded-2xl mx-auto mb-4 bg-[var(--color-bg)] shadow-[6px_6px_12px_#d0d5da,-6px_-6px_12px_#ffffff] flex items-center justify-center overflow-hidden transition-all duration-300 group-hover:scale-105">
                                <img v-if="red.imagen" :src="red.imagen" :alt="red.titulo" class="h-full w-full object-contain p-2" />
                                <span v-else class="text-2xl font-bold" :style="{ color: 'var(--color-primary)' }">{{ red.titulo.charAt(0) }}</span>
                            </div>
                            <h4 class="text-base font-bold mb-2 text-gray-800">{{ red.titulo }}</h4>
                            <p class="text-sm text-gray-500 mb-6 min-h-[42px]">{{ red.descripcion }}</p>
                            <a :href="red.link" target="_blank" rel="noopener noreferrer"
                               class="inline-flex items-center gap-1 text-sm font-semibold transition-all duration-200 hover:gap-2"
                               :style="{ color: 'var(--color-primary)' }">
                                Ir a {{ red.titulo }}
                                <span class="w-4 h-4" v-html="getIcon('arrowRight')"></span>
                            </a>
                        </div>
                    </div>
                    <p v-else class="text-center text-gray-500">No hay redes sociales configuradas.</p>
                </div>
            </div>
        </section>

        <section v-else-if="activeSection === 'servicio'" id="servicio" class="h-full overflow-y-auto py-12 md:py-20 px-4 md:px-8">
            <div class="max-w-7xl mx-auto">
                <div class="text-center mb-16">
                    <h2 class="text-3xl md:text-4xl font-bold mb-4" :style="{ color: 'var(--color-primary)' }">Servicio</h2>
                    <div class="w-20 h-1 rounded-full mx-auto" :style="{ backgroundColor: 'var(--color-primary)' }"></div>
                    <p class="text-gray-500 mt-4 max-w-2xl mx-auto">Ofrecemos una amplia gama de servicios de grúas y asistencia vial para cubrir todas tus necesidades.</p>
                </div>

                <p v-if="!serviciosConfigurados.length" class="py-10 text-center text-gray-500">No hay servicios configurados.</p>
                <div v-else class="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
                    <div v-for="svc in serviciosConfigurados" :key="svc.id"
                         class="rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff] transition-all duration-300 hover:shadow-[12px_12px_24px_#c9ced3,-12px_-12px_24px_#ffffff] group">
                        <div class="h-48 p-6 bg-slate-50 rounded-t-3xl flex items-center justify-center border-b border-gray-100">
                            <img v-if="svc.foto" :src="'/storage/' + svc.foto" :alt="svc.tipo" class="h-full w-full object-contain" />
                            <span v-else class="w-12 h-12 text-gray-400" v-html="getIcon('truck')"></span>
                        </div>
                        <div class="p-6">
                            <h3 class="text-xl font-bold mb-2" :style="{ color: svc.color }">{{ svc.tipo }}</h3>
                            <p class="text-gray-500 text-sm mb-5 leading-relaxed">{{ svc.descripcion }}</p>
                            <a href="/register"
                               class="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl text-sm font-semibold text-white transition-all duration-200 shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff] hover:shadow-[6px_6px_12px_#c9ced3,-6px_-6px_12px_#ffffff]"
                               :style="{ backgroundColor: svc.color }">
                                Solicitar
                                <span class="w-4 h-4" v-html="getIcon('arrowRight')"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section v-else id="contacto" class="h-full overflow-y-auto py-12 md:py-20 px-4 md:px-8">
            <div class="max-w-7xl mx-auto">
                <div class="text-center mb-16">
                    <h2 class="text-3xl md:text-4xl font-bold mb-4" :style="{ color: 'var(--color-primary)' }">Contacto</h2>
                    <div class="w-20 h-1 rounded-full mx-auto" :style="{ backgroundColor: 'var(--color-primary)' }"></div>
                    <p class="text-gray-500 mt-4 max-w-2xl mx-auto">Estamos aquí para ayudarte. Contáctanos por cualquier medio.</p>
                </div>

                <div class="grid lg:grid-cols-2 gap-12">
                    <div class="space-y-8">
                        <div class="p-8 rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff]">
                            <h3 class="text-xl font-bold mb-6" :style="{ color: 'var(--color-primary)' }">Información de Contacto</h3>
                            <div class="space-y-5">
                                <div class="flex items-center gap-4">
                                    <div class="w-12 h-12 rounded-2xl bg-[var(--color-bg)] shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff] flex items-center justify-center shrink-0"
                                         :style="{ color: 'var(--color-primary)' }">
                                        <span class="w-5 h-5" v-html="getIcon('phone')"></span>
                                    </div>
                                    <div>
                                        <p class="text-xs text-gray-400 uppercase tracking-wider font-medium">Teléfono</p>
                                        <p class="text-[var(--color-text)] font-medium">{{ empresa.telefono_contacto || '(555) 123-4567' }}</p>
                                    </div>
                                </div>
                                <div class="flex items-center gap-4">
                                    <div class="w-12 h-12 rounded-2xl bg-[var(--color-bg)] shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff] flex items-center justify-center shrink-0"
                                         :style="{ color: 'var(--color-primary)' }">
                                        <span class="w-5 h-5" v-html="getIcon('mail')"></span>
                                    </div>
                                    <div>
                                        <p class="text-xs text-gray-400 uppercase tracking-wider font-medium">Email</p>
                                        <p class="text-[var(--color-text)] font-medium">{{ empresa.email_contacto || 'contacto@sigesga.com' }}</p>
                                    </div>
                                </div>
                                <div class="flex items-center gap-4">
                                    <div class="w-12 h-12 rounded-2xl bg-[var(--color-bg)] shadow-[4px_4px_8px_#d0d5da,-4px_-4px_8px_#ffffff] flex items-center justify-center shrink-0"
                                         :style="{ color: 'var(--color-primary)' }">
                                        <span class="w-5 h-5" v-html="getIcon('pin')"></span>
                                    </div>
                                    <div>
                                        <p class="text-xs text-gray-400 uppercase tracking-wider font-medium">Ubicación</p>
                                        <p class="text-[var(--color-text)] font-medium">{{ empresa.direccion || 'Av. Principal #123, Ciudad' }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="p-8 rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff]">
                            <h3 class="text-xl font-bold mb-6" :style="{ color: 'var(--color-primary)' }">Oficinas</h3>
                            <div class="space-y-4">
                                <div class="p-4 rounded-2xl bg-[var(--color-bg)] shadow-[inset_4px_4px_8px_#d0d5da,inset_-4px_-4px_8px_#ffffff]">
                                    <p class="font-semibold text-gray-800">Oficina Central</p>
                                    <p class="text-sm text-gray-500">Blvd. Corporativo 500, Col. Centro</p>
                                </div>
                                <div class="p-4 rounded-2xl bg-[var(--color-bg)] shadow-[inset_4px_4px_8px_#d0d5da,inset_-4px_-4px_8px_#ffffff]">
                                    <p class="font-semibold text-gray-800">Sucursal Norte</p>
                                    <p class="text-sm text-gray-500">Av. Industrial 1500, Zona Norte</p>
                                </div>
                                <div class="p-4 rounded-2xl bg-[var(--color-bg)] shadow-[inset_4px_4px_8px_#d0d5da,inset_-4px_-4px_8px_#ffffff]">
                                    <p class="font-semibold text-gray-800">Sucursal Sur</p>
                                    <p class="text-sm text-gray-500">Carr. Nacional Km 15, Zona Sur</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="p-8 rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff]">
                        <h3 class="text-xl font-bold mb-6" :style="{ color: 'var(--color-primary)' }">Envíanos un Mensaje</h3>
                        <form v-if="!contactoEnviado" @submit.prevent="submitContacto" class="space-y-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-600 mb-2">Nombre</label>
                                <input v-model="form.nombre" type="text" required
                                       class="w-full px-5 py-3.5 rounded-2xl bg-[var(--color-bg)] shadow-[inset_6px_6px_12px_#d0d5da,inset_-6px_-6px_12px_#ffffff] text-[var(--color-text)] placeholder-gray-400 focus:outline-none transition-all duration-200"
                                       placeholder="Tu nombre completo" />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-600 mb-2">Email</label>
                                <input v-model="form.email" type="email" required
                                       class="w-full px-5 py-3.5 rounded-2xl bg-[var(--color-bg)] shadow-[inset_6px_6px_12px_#d0d5da,inset_-6px_-6px_12px_#ffffff] text-[var(--color-text)] placeholder-gray-400 focus:outline-none transition-all duration-200"
                                       placeholder="tu@correo.com" />
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-600 mb-2">Mensaje</label>
                                <textarea v-model="form.mensaje" required rows="5"
                                          class="w-full px-5 py-3.5 rounded-2xl bg-[var(--color-bg)] shadow-[inset_6px_6px_12px_#d0d5da,inset_-6px_-6px_12px_#ffffff] text-[var(--color-text)] placeholder-gray-400 focus:outline-none transition-all duration-200 resize-none"
                                          placeholder="Escribe tu mensaje aquí..."></textarea>
                            </div>
                            <button type="submit"
                                    class="w-full py-3.5 rounded-2xl text-sm font-semibold text-white transition-all duration-200 shadow-[6px_6px_12px_#d0d5da,-6px_-6px_12px_#ffffff] hover:shadow-[8px_8px_16px_#c9ced3,-8px_-8px_16px_#ffffff] hover:scale-[1.01] active:scale-[0.99]"
                                    :style="{ backgroundColor: 'var(--color-primary)' }">
                                Enviar Mensaje
                            </button>
                        </form>
                        <div v-else class="text-center py-10">
                            <div class="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center" :style="{ backgroundColor: 'var(--color-primary)' }">
                                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
                            </div>
                            <h4 class="text-lg font-bold mb-2" :style="{ color: 'var(--color-primary)' }">¡Mensaje enviado con éxito!</h4>
                            <p class="text-gray-500 text-sm">Nos comunicaremos contigo en las próximas 24 horas.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        </main>

        <footer class="shrink-0 py-3 px-4 md:px-8">
            <div class="max-w-7xl mx-auto">
                <div class="p-8 rounded-3xl bg-[var(--color-bg)] shadow-[8px_8px_16px_#d0d5da,-8px_-8px_16px_#ffffff]">
                    <p class="text-center text-sm text-gray-500">
                        {{ empresa.texto_derechos || `© ${new Date().getFullYear()} ${empresa.nombre || 'SIGESGA'}. Todos los derechos reservados.` }}
                    </p>
                </div>
            </div>
        </footer>
    </div>
</template>

<style>
html,
body {
    overflow: hidden;
}
body {
    background-color: var(--color-bg);
}
@keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}
</style>
