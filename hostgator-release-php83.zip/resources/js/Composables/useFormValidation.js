// Composable para validación de formularios del lado cliente
import { ref, computed } from 'vue'
import { showValidationErrors } from '@/stores/notification'

export function useFormValidation(form, rules) {
  const clientErrors = ref({})
  const submitted = ref(false)

  // Fusiona errores del servidor con errores del cliente
  const mergeErrors = computed(() => {
    const all = { ...form.errors }
    for (const key of Object.keys(clientErrors.value)) {
      if (clientErrors.value[key]) {
        all[key] = clientErrors.value[key]
      }
    }
    return all
  })

  // Obtiene el mensaje de error para un campo específico
  function getError(field) {
    return mergeErrors.value[field] || ''
  }

  // Limpia el error de un campo específico
  function clearFieldError(field) {
    delete clientErrors.value[field]
  }

  // Recorta espacios de todos los campos de texto
  function trimAll() {
    try {
      const data = form.data()
      if (!data) return
      for (const key of Object.keys(data)) {
        if (typeof data[key] === 'string') {
          form[key] = data[key].trim()
        }
      }
      if (form.direccion) {
        for (const key of Object.keys(form.direccion)) {
          if (typeof form.direccion[key] === 'string') {
            form.direccion[key] = form.direccion[key].trim()
          }
        }
      }
    } catch (e) {
      console.error('[useFormValidation] Error en trimAll:', e)
    }
  }

  // Ejecuta todas las reglas de validación definidas
  function validate() {
    submitted.value = true
    const errors = {}
    const data = form.data()
    if (!data) return Object.keys(errors).length === 0

    for (const [field, fieldRules] of Object.entries(rules)) {
      const value = getFieldValue(data, field)
      const messages = []
      for (const rule of fieldRules) {
        const msg = applyRule(field, value, rule, data)
        if (msg) messages.push(msg)
      }
      if (messages.length > 0) {
        errors[field] = messages[0]
      }
    }
    clientErrors.value = errors
    return Object.keys(errors).length === 0
  }

  // Obtiene el valor de un campo anidado usando notación de punto
  function getFieldValue(data, path) {
    return path.split('.').reduce((obj, key) => obj?.[key], data)
  }

  // Aplica una regla de validación a un campo
  function applyRule(field, value, rule, data) {
    if (typeof rule === 'string') {
      const parts = rule.split(':')
      const name = parts[0]
      const param = parts[1]
      return validateRule(name, value, param, data, field)
    }
    if (typeof rule === 'object' && rule.rule) {
      return validateRule(rule.rule, value, rule.param, data, field, rule.message)
    }
    return ''
  }

  // Evalúa una regla de validación individual con su parámetro y mensaje personalizado
  function validateRule(name, value, param, data, field, customMessage) {
    if (value === undefined || value === null) value = ''

    switch (name) {
      case 'required': {
        if (value === '' || value === null || value === undefined) {
          return customMessage || 'Este campo es obligatorio'
        }
        return ''
      }
      case 'selectRequired': {
        if (value === '' || value === null || value === undefined || value === 'Seleccionar...' || value === 'Seleccionar... ' || value === 'Sin aseguradora') {
          return customMessage || 'Debes seleccionar una opción válida'
        }
        return ''
      }
      case 'min': {
        const min = parseInt(param)
        if (value !== '' && typeof value === 'string' && value.length < min) {
          return customMessage || `Mínimo ${min} caracteres`
        }
        const numVal = parseFloat(value)
        if (value !== '' && !isNaN(numVal) && numVal < min) {
          return customMessage || `El valor mínimo es ${min}`
        }
        return ''
      }
      case 'max': {
        const max = parseInt(param)
        if (value !== '' && typeof value === 'string' && value.length > max) {
          return customMessage || `Máximo ${max} caracteres`
        }
        if (value !== '' && typeof value === 'number' && value > max) {
          return customMessage || `El valor máximo es ${max}`
        }
        return ''
      }
      case 'email': {
        if (value !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          return customMessage || 'Ingresa un correo electrónico válido'
        }
        return ''
      }
      case 'numeric': {
        if (value !== '' && isNaN(parseFloat(value))) {
          return customMessage || 'Ingresa un valor numérico válido'
        }
        return ''
      }
      case 'integer': {
        if (value !== '' && (!/^\d+$/.test(value))) {
          return customMessage || 'Ingresa un número entero válido'
        }
        return ''
      }
      case 'min_value': {
        const minVal = parseFloat(param)
        if (value !== '' && parseFloat(value) < minVal) {
          return customMessage || `El valor mínimo es ${minVal}`
        }
        return ''
      }
      case 'max_value': {
        const maxVal = parseFloat(param)
        if (value !== '' && parseFloat(value) > maxVal) {
          return customMessage || `El valor máximo es ${maxVal}`
        }
        return ''
      }
      case 'pattern': {
        if (value !== '' && !new RegExp(param).test(value)) {
          return customMessage || 'Formato inválido'
        }
        return ''
      }
      case 'curp': {
        if (value !== '' && !/^[A-Z]{4}\d{6}[HM][A-Z]{5}[0-9A-Z][0-9]$/.test(value.toUpperCase())) {
          return customMessage || 'CURP inválida (debe tener 18 caracteres alfanuméricos)'
        }
        return ''
      }
      case 'rfc': {
        if (value !== '' && !/^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3}$/.test(value.toUpperCase())) {
          return customMessage || 'RFC inválido'
        }
        return ''
      }
      case 'phone': {
        if (value !== '' && !/^[\d\s\-()+]{7,20}$/.test(value)) {
          return customMessage || 'Teléfono inválido'
        }
        return ''
      }
      case 'placas': {
        if (value !== '' && !/^[A-Z0-9]{3,8}$/.test(value.toUpperCase())) {
          return customMessage || 'Formato de placas inválido. Ejemplo: ABC1234 o 1234ABC'
        }
        return ''
      }
      case 'date': {
        if (value !== '' && isNaN(Date.parse(value))) {
          return customMessage || 'Fecha inválida'
        }
        return ''
      }
      case 'min_date': {
        if (value !== '') {
          const curDate = new Date(value + 'T00:00:00')
          if (param === 'today') {
            const today = new Date()
            today.setHours(0, 0, 0, 0)
            if (curDate <= today) {
              return customMessage || 'La fecha debe ser posterior a hoy.'
            }
          } else {
            const refDate = new Date(param + 'T00:00:00')
            if (curDate <= refDate) {
              return customMessage || `La fecha debe ser posterior a ${param}.`
            }
          }
        }
        return ''
      }
      case 'after_or_equal': {
        if (value && data[param]) {
          const refDate = new Date(data[param])
          const curDate = new Date(value)
          if (curDate < refDate) {
            return customMessage || `Debe ser igual o posterior a la fecha de ${param.replace(/_/g, ' ')}`
          }
        }
        return ''
      }
      case 'exact_years_after': {
        if (value && data[param]) {
          const refDate = new Date(data[param] + 'T00:00:00')
          const curDate = new Date(value + 'T00:00:00')
          if (curDate <= refDate) return customMessage || 'La fecha debe ser posterior.'
          const diffMs = curDate - refDate
          const diffDays = diffMs / (1000 * 60 * 60 * 24)
          const diffYears = diffDays / 365.25
          const rounded = Math.round(diffYears)
          if (rounded < 2 || rounded > 4) {
            return 'La vigencia debe ser de 2, 3 o 4 años exactos a partir de la fecha de expedición.'
          }
          const expectedDate = new Date(refDate)
          expectedDate.setFullYear(expectedDate.getFullYear() + rounded)
          const expectedStr = expectedDate.toISOString().split('T')[0]
          if (value !== expectedStr) {
            return `La vigencia debe ser exactamente ${rounded} años después. Fecha esperada: ${expectedStr.split('-').reverse().join('/')}.`
          }
        }
        return ''
      }
      case 'boolean': {
        if (value !== '' && value !== true && value !== false && value !== 0 && value !== 1 && value !== '0' && value !== '1') {
          return customMessage || 'Valor inválido'
        }
        return ''
      }
      case 'url': {
        if (value !== '' && !/^https?:\/\/.+/.test(value)) {
          return customMessage || 'Ingresa una URL válida (https://...)'
        }
        return ''
      }
      default:
        return ''
    }
  }

  // Limpia errores al escribir en un campo
  function handleInput(field) {
    clearFieldError(field)
    if (typeof form.clearErrors === 'function') {
      form.clearErrors(field)
    }
  }

  // Maneja el envío del formulario con validación previa
  function handleSubmit(callback) {
    return function () {
      try {
        trimAll()
        if (!validate()) {
          const all = Object.values(clientErrors.value).filter(Boolean)
          if (all.length > 0) {
            try {
              showValidationErrors(all)
            } catch (notifError) {
              console.error('[useFormValidation] Error al mostrar errores:', notifError)
            }
          }
          return
        }
        callback()
      } catch (err) {
        console.error('[useFormValidation] Error en handleSubmit:', err)
      }
    }
  }

  return {
    clientErrors,
    submitted,
    mergeErrors,
    getError,
    validate,
    handleInput,
    handleSubmit,
    trimAll,
    clearFieldError,
  }
}
